//
//  ViewController.swift
//  Example_chatbot
//
//  Created by DMP FTI on 28/06/2023.
//

import UIKit
import fptaichatbotsdk
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func startButtonDidTap(_ sender: Any) {
        let config = FChatBotConfig(senderName: "ghhj",
                                            senderID: "40FF8EDB-BD11-45CF-A036-04640A16BE1D",
                                            token: "2wiNUSSWdpVJ-UwJ-yV3Osikr69B77cJtFkZ-5azH2W1FUbuwPrYDc1MV844BRNUdCMSWjyopBCjHfAgoL3grobTeFfPIHZC6rHtaFbSSvSKe8L8ySTkwwuAqRk2XxQ",
                                            botCode: "a1f52b1ae49deb2d1c378a0ecf7fe891")

//        let config = FChatBotConfig(senderName: "ghhj",
//                                    senderID: "40FF8EDB-BD11-45CF-A036-04640A16BE1D",
//                                    token: "2wiNUSSWdpVJ-UwJ-yV3Osikr69B77cJtFkZ-5azH2W1FUbuwPrYDc1MV844BRNUdCMSWjyopBCjHfAgoL3grobTeFfPIHZC6rHtaFbSSvSKe8L8ySTkwwuAqRk2XxQ",
//                                    botCode: "a1f52b1ae49deb2d1c378a0ecf7fe891")
        
        FChatBot.startFPTChatbot(withConfig: config, from: self) {_ in
            // do nothing
        }
    }

}

